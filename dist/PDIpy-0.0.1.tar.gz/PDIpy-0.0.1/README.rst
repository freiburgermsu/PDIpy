PDIpy Module Repository
=============================

This module simulation photodynamic inactivation for bacteria.

------------------------------------------------------------------